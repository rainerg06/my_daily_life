package com.example.diary

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
