import 'package:flutter/material.dart';

class DiaryPage extends StatelessWidget {
  const DiaryPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Diary Page', style: TextStyle(fontSize: 50)));
  }
}
