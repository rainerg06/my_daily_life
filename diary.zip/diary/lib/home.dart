import 'dart:math';

import 'package:flutter/material.dart';

void main() {
  runApp(const HomePage());
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Wheel of To-Do List',
      home: const ToDoHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class ToDoHomePage extends StatefulWidget {
  const ToDoHomePage({super.key});

  @override
  State<ToDoHomePage> createState() => _ToDoHomePageState();
}

class _ToDoHomePageState extends State<ToDoHomePage> {
  int _selectedIndex = 0;

  final List<String> _tasks = [
    'Valorant',
    'Roblox',
    'Dota',
    'League of Legends',
    'NBA2K',
    'Volleyball',
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Future<void> _handleTaskSelected(String task) async {
    final shouldRemove = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Task Selected'),
        content: Text('Your wheel landed on "${task.trim()}".'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Keep Task'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Okay'),
          ),
        ],
      ),
    );

    if (shouldRemove == true) {
      setState(() {
        _tasks.remove(task);
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Removed "$task" from your list.'),
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }

  void _showTaskManager() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, modalSetState) {
            Future<void> refreshSheet() async {
              modalSetState(() {});
              setState(() {});
            }

            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 24,
                bottom: MediaQuery.of(context).viewInsets.bottom + 24,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Manage Tasks',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (_tasks.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      child: Text(
                        'No tasks yet. Tap "Add task" to create one.',
                        style: TextStyle(color: Colors.grey),
                      ),
                    )
                  else
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxHeight: 280),
                      child: ListView.separated(
                        shrinkWrap: true,
                        padding: EdgeInsets.zero,
                        itemCount: _tasks.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, index) {
                          final task = _tasks[index];
                          return ListTile(
                            title: Text(task),
                            leading: const Icon(Icons.task_alt_outlined),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  tooltip: 'Edit',
                                  icon: const Icon(Icons.edit_outlined),
                                  onPressed: () async {
                                    await _promptEditTask(index);
                                    await refreshSheet();
                                  },
                                ),
                                IconButton(
                                  tooltip: 'Delete',
                                  icon: const Icon(Icons.delete_outline),
                                  onPressed: () {
                                    _deleteTask(index);
                                    refreshSheet();
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  const SizedBox(height: 20),
                  FilledButton.icon(
                    onPressed: () async {
                      await _promptAddTask();
                      await refreshSheet();
                    },
                    icon: const Icon(Icons.add),
                    label: const Text('Add task'),
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFFD9A066),
                      foregroundColor: Colors.white,
                      minimumSize: const Size.fromHeight(48),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _promptAddTask() async {
    final newTask = await _promptForTask();
    if (newTask == null || newTask.trim().isEmpty) {
      return;
    }
    setState(() {
      _tasks.add(newTask.trim());
    });
  }

  Future<void> _promptEditTask(int index) async {
    final editedTask = await _promptForTask(initialValue: _tasks[index]);
    if (editedTask == null || editedTask.trim().isEmpty) {
      return;
    }
    setState(() {
      _tasks[index] = editedTask.trim();
    });
  }

  void _deleteTask(int index) {
    final removedTask = _tasks[index];
    setState(() {
      _tasks.removeAt(index);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Deleted "$removedTask".'),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<String?> _promptForTask({String? initialValue}) {
    final controller = TextEditingController(text: initialValue);
    return showDialog<String>(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Text(initialValue == null ? 'Add Task' : 'Edit Task'),
          content: TextField(
            controller: controller,
            autofocus: true,
            decoration: const InputDecoration(
              hintText: 'Describe your task',
            ),
            onSubmitted: (value) => Navigator.of(context).pop(value),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(controller.text),
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePageContent(
        tasks: _tasks,
        onTaskSelected: _handleTaskSelected,
        onManageTasks: _showTaskManager,
      ),
      const DiaryPage(),
      const WeatherPage(),
      const ProfilePage(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFFDF6E3),
      body: SafeArea(child: pages[_selectedIndex]),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
        backgroundColor: const Color(0xFFFDF6E3),
        selectedItemColor: Colors.brown,
        unselectedItemColor: Colors.brown[300],
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: 'Diary'),
          BottomNavigationBarItem(icon: Icon(Icons.cloud), label: 'Weather'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePageContent extends StatelessWidget {
  const HomePageContent({
    super.key,
    required this.tasks,
    required this.onTaskSelected,
    required this.onManageTasks,
  });

  final List<String> tasks;
  final ValueChanged<String> onTaskSelected;
  final VoidCallback onManageTasks;

  @override
  Widget build(BuildContext context) {
    const headlineColor = Color(0xFF8B5A2B);

    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Good afternoon,\nRainer!',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 40,
                fontWeight: FontWeight.w700,
                color: headlineColor,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Here is your To-do list:',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 22,
                color: headlineColor,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 28),
            Stack(
              alignment: Alignment.center,
              clipBehavior: Clip.none,
              children: [
                ToDoWheel(
                  tasks: tasks,
                  onTaskSelected: onTaskSelected,
                ),
                Positioned(
                  right: -18,
                  child: FloatingActionButton.small(
                    heroTag: 'manage_tasks_fab',
                    onPressed: onManageTasks,
                    backgroundColor: const Color(0xFFD9A066),
                    child: const Icon(Icons.add, color: Colors.white),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),
            const Text(
              'Wheel of To-Do List',
              style: TextStyle(
                fontSize: 24,
                color: headlineColor,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ToDoWheel extends StatefulWidget {
  const ToDoWheel({
    super.key,
    required this.tasks,
    required this.onTaskSelected,
  });

  final List<String> tasks;
  final ValueChanged<String> onTaskSelected;

  @override
  State<ToDoWheel> createState() => _ToDoWheelState();
}

class _ToDoWheelState extends State<ToDoWheel>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late Animation<double> _animation;
  double _currentRotation = 0.0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 2200),
      vsync: this,
    );
    _animation = AlwaysStoppedAnimation(_currentRotation);
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        final task = _calculateSelectedTask();
        if (task != null) {
          widget.onTaskSelected(task);
        }
      }
    });
  }

  void _animationListener() {
    setState(() {
      _currentRotation = _animation.value;
    });
  }

  void _spinWheel() {
    if (widget.tasks.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Add at least one task before spinning.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    final random = Random();
    final double spins = 4 + random.nextDouble() * 2; // between 4 and 6 spins
    final double segmentVariance =
        random.nextDouble() * (2 * pi / widget.tasks.length);
    final double targetRotation =
        _currentRotation + spins * 2 * pi + segmentVariance;

    _animation.removeListener(_animationListener);
    final curvedAnimation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutQuart,
    );
    _animation = Tween<double>(
      begin: _currentRotation,
      end: targetRotation,
    ).animate(curvedAnimation)
      ..addListener(_animationListener);

    _controller
      ..reset()
      ..forward();
  }

  String? _calculateSelectedTask() {
    if (widget.tasks.isEmpty) {
      return null;
    }
    final totalTasks = widget.tasks.length;
    final double anglePerTask = 2 * pi / totalTasks;
    
    // In Flutter's coordinate system:
    // - angle 0 is at the right (3 o'clock)
    // - angle pi/2 is at the bottom (6 o'clock)  
    // - angle pi is at the left (9 o'clock)
    // - angle 3*pi/2 (or -pi/2) is at the top (12 o'clock)
    // The pointer is fixed at the top, which is at angle 3*pi/2
    
    final double normalizedRotation = _currentRotation % (2 * pi);
    const double pointerAngle = 3 * pi / 2; // Top position (12 o'clock)
    
    // Find segment whose center is closest to the pointer at the top
    int selectedIndex = 0;
    double minDistance = double.infinity;
    
    for (int i = 0; i < totalTasks; i++) {
      // Segment i's center angle in original position (before rotation)
      // Segment 0 starts at angle 0 (right), so center of segment i is:
      double originalCenterAngle = i * anglePerTask + anglePerTask / 2;
      
      // After rotation, segment center is at:
      double rotatedCenterAngle = (originalCenterAngle + normalizedRotation) % (2 * pi);
      
      // Calculate angular distance from pointer at 3*pi/2
      // Use the shorter arc distance (wrap around the circle)
      double distance1 = (rotatedCenterAngle - pointerAngle).abs();
      double distance2 = 2 * pi - distance1;
      double distance = distance1 < distance2 ? distance1 : distance2;
      
      if (distance < minDistance) {
        minDistance = distance;
        selectedIndex = i;
      }
    }
    
    return widget.tasks[selectedIndex];
  }

  @override
  void didUpdateWidget(covariant ToDoWheel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.tasks.isEmpty && oldWidget.tasks.isNotEmpty) {
      setState(() {
        _currentRotation = 0;
      });
    }
  }

  @override
  void dispose() {
    _animation.removeListener(_animationListener);
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 260,
      width: 260,
      child: Stack(
        alignment: Alignment.center,
        clipBehavior: Clip.none,
        children: [
          Positioned(
            top: -20,
            child: Icon(
              Icons.arrow_drop_down,
              size: 44,
              color: Colors.brown[700],
            ),
          ),
          Transform.rotate(
            angle: _currentRotation,
            child: CustomPaint(
              size: const Size.square(240),
              painter: WheelPainter(widget.tasks),
            ),
          ),
          SizedBox(
            height: 80,
            width: 80,
            child: ElevatedButton(
              onPressed: _spinWheel,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFD9A066),
                foregroundColor: Colors.white,
                shape: const CircleBorder(),
                elevation: 6,
                padding: EdgeInsets.zero,
              ),
              child: const Text(
                'SPIN',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.2,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class WheelPainter extends CustomPainter {
  WheelPainter(this.items);

  final List<String> items;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final fillPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = const Color(0xFFFFF4D8);
    canvas.drawCircle(center, radius, fillPaint);

    final borderPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..color = Colors.brown[600]!;
    canvas.drawCircle(center, radius, borderPaint);

    if (items.isEmpty) {
      final textPainter = TextPainter(
        textAlign: TextAlign.center,
        textDirection: TextDirection.ltr,
      );
      textPainter.text = const TextSpan(
        text: 'Add tasks to spin',
        style: TextStyle(
          fontSize: 14,
          color: Colors.brown,
        ),
      );
      textPainter.layout();
      textPainter.paint(
        canvas,
        Offset(center.dx - textPainter.width / 2, center.dy - textPainter.height / 2),
      );
      return;
    }

    final double anglePerItem = 2 * pi / items.length;
    final dividerPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..color = Colors.brown[400]!;

    for (int i = 0; i < items.length; i++) {
      final startAngle = i * anglePerItem;
      canvas.drawLine(
        center,
        Offset(
          center.dx + radius * cos(startAngle),
          center.dy + radius * sin(startAngle),
        ),
        dividerPaint,
      );

      final textPainter = TextPainter(
        textAlign: TextAlign.center,
        textDirection: TextDirection.ltr,
      );
      final textSpan = TextSpan(
        text: items[i],
        style: TextStyle(
          fontSize: 14,
          color: Colors.brown[700],
          fontWeight: FontWeight.w600,
        ),
      );
      textPainter.text = textSpan;
      textPainter.layout(maxWidth: radius * 0.7);
      final labelAngle = startAngle + anglePerItem / 2;
      final textOffset = Offset(
        center.dx + radius * 0.55 * cos(labelAngle) - textPainter.width / 2,
        center.dy + radius * 0.55 * sin(labelAngle) - textPainter.height / 2,
      );
      textPainter.paint(canvas, textOffset);
    }

    // Center circle to cover the button area
    canvas.drawCircle(center, radius * 0.33, Paint()..color = Colors.white);
    canvas.drawCircle(
      center,
      radius * 0.33,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = Colors.brown[500]!,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class DiaryPage extends StatelessWidget {
  const DiaryPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Diary Page',
        style: TextStyle(fontSize: 24, color: Colors.brown),
      ),
    );
  }
}

class WeatherPage extends StatelessWidget {
  const WeatherPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Weather Page',
        style: TextStyle(fontSize: 24, color: Colors.brown),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Profile Page',
        style: TextStyle(fontSize: 24, color: Colors.brown),
      ),
    );
  }
}
