import 'dart:math';

import 'package:flutter/material.dart';

void main() {
  runApp(HomePage());
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Wheel of To-Do List',
      home: ToDoHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class ToDoHomePage extends StatefulWidget {
  @override
  _ToDoHomePageState createState() => _ToDoHomePageState();
}

class _ToDoHomePageState extends State<ToDoHomePage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    HomePageContent(),
    DiaryPage(),
    WeatherPage(),
    ProfilePage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFDF6E3),
      body: SafeArea(child: _pages[_selectedIndex]),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
        backgroundColor: Color(0xFFFDF6E3),
        selectedItemColor: Colors.brown,
        unselectedItemColor: Colors.brown[300],
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: 'Diary'),
          BottomNavigationBarItem(icon: Icon(Icons.cloud), label: 'Weather'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePageContent extends StatelessWidget {
  final List<String> tasks = [
    'Valorant',
    'Roblox',
    'Dota',
    'LOL',
    'NBA2k',
    'Volleyball',
  ];

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30.0),
          child: Column(
            children: [
              SizedBox(height: 30),
              Text(
                'Good afternoon,\nRainer!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: Colors.brown[800],
                ),
              ),
              SizedBox(height: 10),
              Text(
                'Here is your To-do list:',
                style: TextStyle(fontSize: 25, color: Colors.brown[600]),
              ),
              SizedBox(height: 30),
              ToDoWheel(tasks: tasks),
              SizedBox(height: 40),
              Text(
                'Wheel of To-Do List',
                style: TextStyle(fontSize: 30, color: Colors.brown[700]),
              ),
              SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}

class ToDoWheel extends StatefulWidget {
  final List<String> tasks;
  const ToDoWheel({required this.tasks});

  @override
  _ToDoWheelState createState() => _ToDoWheelState();
}

class _ToDoWheelState extends State<ToDoWheel>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  double _currentRotation = 0.0;
  String? _selectedTask;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    final curve = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    );
    _animation = Tween<double>(begin: 0, end: 0).animate(curve)
      ..addListener(() {
        setState(() {
          _currentRotation = _animation.value;
        });
      });
  }

  void spinWheel() {
    final double spins = 4 + Random().nextDouble() * 2; // 4 to 6
    final double newRotation = _currentRotation + spins * 2 * pi;

    _animation =
        Tween<double>(begin: _currentRotation, end: newRotation).animate(
          CurvedAnimation(parent: _controller, curve: Curves.easeOutQuart),
        )..addListener(() {
          setState(() {
            _currentRotation = _animation.value;
          });
        });
    {
      _selectTask();
    }
    _controller.reset();
    _controller.forward();
  }

  void _selectTask() {
    final totalTasks = widget.tasks.length;
    final double normalizedRotation = _currentRotation % (2 * pi);
    final double angelePerTask = 2 * pi / totalTasks;
    final int selectedIndex =
        ((2 * pi - normalizedRotation + angelePerTask / 2) ~/ angelePerTask) %
        totalTasks;

    setState(() {
      _selectedTask = widget.tasks[selectedIndex];
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Stack(
          alignment: Alignment.center,

          children: [
            // Pointer at the top
            Positioned(
              top: 0,

              child: Icon(
                Icons.arrow_drop_down,
                size: 40,
                color: Colors.brown[700],
              ),
            ),

            // Wheel
            Transform.rotate(
              angle: _currentRotation,

              child: Container(
                width: 240,

                height: 240,

                child: CustomPaint(painter: WheelPainter(widget.tasks)),
              ),
            ),

            // Spin Button
            ElevatedButton(
              onPressed: spinWheel,

              child: Text('SPIN'),

              style: ElevatedButton.styleFrom(
                shape: CircleBorder(),

                padding: EdgeInsets.all(24),

                backgroundColor: Colors.brown[300],

                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),

        SizedBox(height: 20),

        //  Show selected task
        if (_selectedTask != null)
          Text(
            'Selected Task: $_selectedTask',

            style: TextStyle(
              fontSize: 18,

              fontWeight: FontWeight.bold,

              color: Colors.brown[800],
            ),
          ),
      ],
    );
  }
}

class WheelPainter extends CustomPainter {
  final List<String> items;
  WheelPainter(this.items);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..color = Colors.brown
      ..strokeWidth = 2;

    final textPainter = TextPainter(
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    );

    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    final anglePerItem = 2 * pi / items.length;

    for (int i = 0; i < items.length; i++) {
      final angle = i * anglePerItem;

      // Draw lines from center to edge
      canvas.drawLine(
        center,
        Offset(
          center.dx + radius * cos(angle),
          center.dy + radius * sin(angle),
        ),
        paint,
      );

      // Draw text
      final textSpan = TextSpan(
        text: items[i],
        style: TextStyle(fontSize: 12, color: Colors.brown[800]),
      );
      textPainter.text = textSpan;
      textPainter.layout();

      final labelAngle = angle + anglePerItem / 2;
      final textOffset = Offset(
        center.dx + radius * 0.6 * cos(labelAngle) - textPainter.width / 2,
        center.dy + radius * 0.6 * sin(labelAngle) - textPainter.height / 2,
      );
      textPainter.paint(canvas, textOffset);
    }

    // Draw outer circle
    canvas.drawCircle(center, radius, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class DiaryPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Diary Page',
        style: TextStyle(fontSize: 24, color: Colors.brown),
      ),
    );
  }
}

class WeatherPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Weather Page',
        style: TextStyle(fontSize: 24, color: Colors.brown),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Profile Page',
        style: TextStyle(fontSize: 24, color: Colors.brown),
      ),
    );
  }
}
