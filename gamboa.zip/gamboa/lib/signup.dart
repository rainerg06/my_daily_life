import 'package:flutter/material.dart';

class SignUpPage extends StatelessWidget {
  final Color primaryColor = Color(0xFFD9A066);

  final Color bgColor = Color(0xFFFFF9F0);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,

      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),

        child: Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Text(
                  'SIGN UP',

                  style: TextStyle(
                    fontSize: 65,

                    fontWeight: FontWeight.bold,

                    color: Colors.brown[800],
                  ),
                ),

                SizedBox(height: 20),

                Image.asset('assets/images/logo.png', height: 200, width: 500),

                SizedBox(height: 30),

                Align(
                  alignment: Alignment.centerLeft,

                  child: Text(
                    'Name',

                    style: TextStyle(fontSize: 16, color: Colors.brown),
                  ),
                ),

                TextField(
                  decoration: InputDecoration(
                    hintText: 'Enter your name',

                    filled: true,

                    fillColor: Colors.white,

                    border: OutlineInputBorder(),
                  ),
                ),

                SizedBox(height: 15),

                Align(
                  alignment: Alignment.centerLeft,

                  child: Text(
                    'Email',

                    style: TextStyle(fontSize: 16, color: Colors.brown),
                  ),
                ),

                TextField(
                  decoration: InputDecoration(
                    hintText: 'Enter your email',

                    filled: true,

                    fillColor: Colors.white,

                    border: OutlineInputBorder(),
                  ),
                ),

                SizedBox(height: 15),

                Align(
                  alignment: Alignment.centerLeft,

                  child: Text(
                    'Password',

                    style: TextStyle(fontSize: 16, color: Colors.brown),
                  ),
                ),

                TextField(
                  obscureText: true,

                  decoration: InputDecoration(
                    hintText: 'Enter your password',

                    filled: true,

                    fillColor: Colors.white,

                    border: OutlineInputBorder(),
                  ),
                ),

                SizedBox(height: 30),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,

                    padding: EdgeInsets.symmetric(
                      horizontal: 100,
                      vertical: 15,
                    ),

                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),

                  onPressed: () {
                    // handle signup logic
                  },

                  child: Text('Sign up', style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
