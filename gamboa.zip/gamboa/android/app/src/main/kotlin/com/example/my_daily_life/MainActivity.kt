package com.example.my_daily_life

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
